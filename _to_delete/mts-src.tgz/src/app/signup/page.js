"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import Turnstile, { captchaEnabled } from "@/components/Turnstile";

/**
 * Signup attribution. Captured into auth metadata at sign-up; the
 * handle_new_user trigger copies it onto profiles. It has to ride along in
 * options.data because with email confirmation on there is no session (and so
 * no way to write to profiles) at this moment. Impossible to reconstruct
 * retroactively, which is why it is captured here rather than later.
 */
function signupAttribution() {
  if (typeof window === "undefined") return {};
  try {
    // First touch, stashed by the attr-capture script in the root layout.
    const stored = JSON.parse(sessionStorage.getItem("mts_attr") || "{}");
    // Anything on the /signup URL itself wins over the stashed first touch.
    const p = new URLSearchParams(window.location.search);
    const here = {};
    for (const k of ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"]) {
      const v = p.get(k);
      if (v) here[k] = v.slice(0, 200);
    }
    if (!here.utm_source && p.get("src")) here.utm_source = p.get("src").slice(0, 200);
    return { ...stored, ...here };
  } catch {
    return {};
  }
}

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [needsConfirm, setNeedsConfirm] = useState(false);
  const [captchaToken, setCaptchaToken] = useState(null);
  const [captchaReset, setCaptchaReset] = useState(0);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const supabase = createClient();
    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName, ...signupAttribution() },
        captchaToken: captchaToken || undefined,
      },
    });

    setLoading(false);

    if (signUpError) {
      setCaptchaReset((n) => n + 1); // tokens are single-use
      setError(signUpError.message);
      return;
    }

    // If email confirmation is enabled, there's no session yet
    if (!data.session) {
      setNeedsConfirm(true);
      return;
    }

    router.push("/dashboard");
    router.refresh();
  }

  if (needsConfirm) {
    return (
      <AuthShell title="CHECK YOUR EMAIL">
        <p className="text-slate-400 text-center leading-relaxed">
          We just sent a confirmation link to <span className="text-white font-semibold">{email}</span>.
          Click it to activate your coach account — it signs you in automatically.
        </p>
        <div className="bg-white/[0.04] border border-white/[0.08] rounded-lg px-4 py-3 mt-5 text-sm text-slate-400 text-left space-y-1.5">
          <p>📨 It comes from <span className="text-white">My-Team Sports (noreply@my-teamsports.com)</span> — usually within a minute or two.</p>
          <p>📬 Don&apos;t see it? <span className="text-white">Check your spam or Promotions folder.</span></p>
          <p>📱 The link works from <span className="text-white">any device</span> — phone or computer.</p>
        </div>
        <p className="text-slate-500 text-sm text-center mt-5">
          Already confirmed?{" "}
          <Link href="/login" className="text-[var(--color-accent-blue)] hover:underline">Log in</Link>
        </p>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="CREATE YOUR COACH ACCOUNT" subtitle="Half off for the 2026 season. Set up your team in minutes.">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Your Name" type="text" value={fullName} onChange={setFullName} placeholder="Coach Smith" required />
        <Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@example.com" required />
        <Field label="Password" type="password" value={password} onChange={setPassword} placeholder="At least 6 characters" required minLength={6} />
        <Turnstile onToken={setCaptchaToken} resetSignal={captchaReset} />
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <button
          type="submit"
          disabled={loading || (captchaEnabled && !captchaToken)}
          className="w-full bg-[var(--color-accent-green)] text-white font-[family-name:var(--font-oswald)] text-lg font-semibold tracking-wide py-3.5 rounded-xl hover:bg-green-500 transition-all disabled:opacity-50"
        >
          {loading ? "Creating account..." : "SIGN UP"}
        </button>
      </form>
      <p className="text-sm text-slate-500 text-center mt-6">
        Already have an account?{" "}
        <Link href="/login" className="text-[var(--color-accent-blue)] hover:underline">Log in</Link>
      </p>
    </AuthShell>
  );
}

function AuthShell({ title, subtitle, children }) {
  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-gradient-to-b from-[var(--color-navy)] to-[var(--color-navy-mid)]">
      <div className="w-full max-w-md">
        <Link href="/" className="flex items-center justify-center gap-3 mb-8">
          <div className="w-11 h-11 bg-gradient-to-br from-[var(--color-accent-blue)] to-blue-700 rounded-xl flex items-center justify-center text-lg">⚾</div>
          <span className="font-[family-name:var(--font-oswald)] font-bold text-xl tracking-wide text-white">
            MY-TEAM <span className="text-[var(--color-accent-blue)]">SPORTS</span>
          </span>
        </Link>
        <div className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-8">
          <h1 className="text-2xl font-bold text-center mb-2">{title}</h1>
          {subtitle && <p className="text-slate-400 text-sm text-center mb-6">{subtitle}</p>}
          {children}
        </div>
      </div>
    </div>
  );
}

function Field({ label, type, value, onChange, placeholder, required, minLength }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-400 mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        minLength={minLength}
        className="w-full bg-white/[0.05] border border-white/[0.1] rounded-lg px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:border-[var(--color-accent-blue)] transition-colors"
      />
    </div>
  );
}
