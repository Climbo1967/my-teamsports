import Script from "next/script";
import { Analytics } from "@vercel/analytics/next";
import { Oswald, Source_Sans_3 } from "next/font/google";
import "./globals.css";

const oswald = Oswald({
  variable: "--font-oswald",
  subsets: ["latin"],
});

const sourceSans = Source_Sans_3({
  variable: "--font-source-sans",
  subsets: ["latin"],
});

const SITE_URL = "https://my-teamsports.com";
const SITE_DESCRIPTION =
  "Give your youth sports team a beautiful website in 5 minutes — roster, schedule, stats, photos, and game film. Parents never download an app, create an account, or pay a dime.";

export const metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Youth Sports Team Website - No App Required | My-Team Sports",
    template: "%s | My-Team Sports",
  },
  description: SITE_DESCRIPTION,
  applicationName: "My-Team Sports",
  appleWebApp: {
    capable: true,
    title: "My-Team Sports",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/icon-192.png",
    apple: "/icon-192.png",
  },
  keywords: [
    "youth sports team website",
    "free team website",
    "team roster app",
    "team schedule maker",
    "youth baseball team site",
    "no app team management",
    "sports team communication",
    "team stats tracker",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: SITE_URL,
    siteName: "My-Team Sports",
    title: "Youth Sports Team Website - No App Required | My-Team Sports",
    description: SITE_DESCRIPTION,
    locale: "en_US",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "My-Team Sports — free youth sports team websites, no app needed",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Youth Sports Team Website - No App Required | My-Team Sports",
    description: SITE_DESCRIPTION,
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
};

export const viewport = {
  themeColor: "#0a0e1a",
};

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": `${SITE_URL}/#organization`,
      name: "My-Team Sports",
      url: SITE_URL,
      logo: `${SITE_URL}/icon-512.png`,
      description: SITE_DESCRIPTION,
    },
    {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      url: SITE_URL,
      name: "My-Team Sports",
      publisher: { "@id": `${SITE_URL}/#organization` },
    },
    {
      "@type": "SoftwareApplication",
      name: "My-Team Sports",
      applicationCategory: "SportsApplication",
      operatingSystem: "Web",
      url: SITE_URL,
      description: SITE_DESCRIPTION,
      offers: { "@type": "Offer", price: "15", priceCurrency: "USD", priceValidUntil: "2026-12-31" },
    },
  ],
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Script async src="https://www.googletagmanager.com/gtag/js?id=G-NPD6LYL7RF" strategy="afterInteractive" />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-NPD6LYL7RF');
          `}
        </Script>
        {/* First-touch signup attribution. UTM tags land on whatever page the
            cold-email link points at — usually the homepage, not /signup — so
            we stash them once per session and read them back at sign-up.
            First touch wins; later pageviews never overwrite it. */}
        <Script id="attr-capture" strategy="afterInteractive">
          {`try{if(!sessionStorage.getItem('mts_attr')){var q=new URLSearchParams(location.search),a={},k=['utm_source','utm_medium','utm_campaign','utm_content','utm_term'];for(var i=0;i<k.length;i++){var v=q.get(k[i]);if(v)a[k[i]]=v.slice(0,200);}if(!a.utm_source&&q.get('src'))a.utm_source=q.get('src').slice(0,200);if(document.referrer&&document.referrer.indexOf(location.origin)!==0)a.referrer=document.referrer.slice(0,400);a.landing_path=(location.pathname+location.search).slice(0,400);sessionStorage.setItem('mts_attr',JSON.stringify(a));}}catch(e){}`}
        </Script>
        <Script id="sw-register" strategy="afterInteractive">
          {`if ('serviceWorker' in navigator) { window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js').catch(function(){}); }); }`}
        </Script>
      </head>
      <body
        className={`${oswald.variable} ${sourceSans.variable} antialiased`}
      >
        {children}
        <Analytics />
      </body>
    </html>
  );
}
