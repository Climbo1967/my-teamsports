import { cookies } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { signMediaUrls } from "@/lib/media";
import { SPORT_EMOJI, sportLabel, computeRecord, formatRecord, hexToRgba, DEFAULT_TEAM_COLOR } from "@/lib/constants";
import PasscodeGate from "./PasscodeGate";
import TeamSiteSections from "./TeamSiteSections";
import LiveScoreBanner from "./LiveScoreBanner";
import PushOptIn from "./PushOptIn";
import ViewPing from "@/components/ViewPing";

export async function generateMetadata({ params }) {
  const { slug } = await params;
  return { title: `Team Site | My-Team Sports`, robots: { index: false } };
}

export default async function TeamPage({ params }) {
  const { slug } = await params;
  const normalizedSlug = String(slug).toLowerCase();

  const cookieStore = await cookies();
  const passcode = cookieStore.get(`team_access_${normalizedSlug}`)?.value;

  let site = null;
  if (passcode) {
    const supabase = await createClient();
    const { data } = await supabase.rpc("get_team_site", {
      p_slug: normalizedSlug,
      p_passcode: passcode,
    });
    site = data;
  }

  if (!site) {
    return <PasscodeGate slug={normalizedSlug} />;
  }

  // The bucket is private and the RPC returns stored object paths — turn the
  // logo, player headshots, and gallery photos into signed URLs in one batch
  // before anything renders.
  const admin = createAdminClient();
  const players = site.players || [];
  const photos = site.photos || [];
  const values = [site.team.logo_url, ...players.map((p) => p.photo_url), ...photos.map((ph) => ph.url)];
  const signed = await signMediaUrls(admin, values);
  site = {
    ...site,
    team: { ...site.team, logo_url: signed[0] },
    players: players.map((p, i) => ({ ...p, photo_url: signed[1 + i] })),
    photos: photos.map((ph, i) => ({ ...ph, url: signed[1 + players.length + i] })),
  };

  const emoji = SPORT_EMOJI[site.team.sport] || "🏆";
  const record = computeRecord(site.events);
  const teamColor = site.team.primary_color || DEFAULT_TEAM_COLOR;

  return (
    <div className="min-h-screen bg-[var(--color-navy)]">
      <ViewPing pageKey="team" />
      {/* TEAM HEADER */}
      <header className="relative bg-gradient-to-b from-[#0d1f3c] to-[var(--color-navy)] border-b border-white/5 px-6 py-14 text-center overflow-hidden">
        <div className="absolute inset-x-0 top-0 h-1.5" style={{ backgroundColor: teamColor }} />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-full" style={{ background: `radial-gradient(ellipse at top, ${hexToRgba(teamColor, 0.12)}, transparent 70%)` }} />
        <div className="relative">
          {site.team.logo_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={site.team.logo_url}
              alt={site.team.name}
              className="w-24 h-24 mx-auto mb-4 rounded-2xl object-cover border border-white/10 shadow-xl"
            />
          ) : (
            <div className="text-6xl mb-4">{emoji}</div>
          )}
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">{site.team.name.toUpperCase()}</h1>
          <p className="text-slate-400 mt-2 capitalize">
            {sportLabel(site.team.sport)}{site.team.season ? ` · ${site.team.season}` : ""}
          </p>
          {record.played > 0 && (
            <div className="inline-flex items-center gap-2 mt-4 bg-white/[0.05] border border-white/10 rounded-full px-5 py-2">
              <span className="text-xs uppercase tracking-widest text-slate-500">Record</span>
              <span className="font-[family-name:var(--font-oswald)] text-xl font-bold text-[var(--color-accent-green)]">
                {formatRecord(record)}
              </span>
            </div>
          )}
        </div>
      </header>

      <LiveScoreBanner slug={normalizedSlug} teamName={site.team.name} />

      <PushOptIn slug={normalizedSlug} teamName={site.team.name} />

      <TeamSiteSections site={site} slug={normalizedSlug} emoji={emoji} />

      <footer className="px-6 py-10 text-center border-t border-white/5">
        <p className="text-xs text-slate-600">
          Powered by{" "}
          <a href="https://my-teamsports.com" className="font-semibold text-slate-500 hover:text-slate-400">
            MY-TEAM SPORTS.com
          </a>
        </p>
      </footer>
    </div>
  );
}
