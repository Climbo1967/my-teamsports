# Handoff Kit — Finish my-teamsports Security Work

> ## ✅ ALL WORK IN THIS KIT IS COMPLETE (2026-07-10)
> Executed and verified live by the Claude Code session on 2026-07-10:
> 1. **Next 16.2.10 actually shipped** — lockfile was still pinning 16.1.6 (so Vercel's `npm ci` had been building the vulnerable version); reconciled and deployed (`ab77692`).
> 2. **CSP enforced** (`ed04eff`) — after first adding Google Analytics + YouTube/Vimeo origins the old allowlist would have broken; zero violations on live prod.
> 3. **Rate limiting → shared Postgres store** (`675c369`) — live burst test: 429 at request 11 on `team-access`. (A later Upstash directive was cancelled — the Supabase counter was already live and verified.)
> 4. **Private photo bucket + signed URLs** (`69cd79a`) — deployed, parent flow E2E-verified, bucket flipped private, raw public URL blocked (400), orphan deleted.
>
> Current status lives in `security-review-2026-07.md`. Everything below is retained for historical context only — do not re-execute.

Give this to a **Claude Code session** (or a developer) that has the repo checked out with **git push access** and can run a local build. That turns the remaining items into clean, tested branches instead of blind web-editor edits.

---

## 1. What to give the coding session

**A. The repo (with write access).**
- GitHub repo: `Climbo1967/my-teamsports` (branch `main`).
- Run the session on a machine that's logged into GitHub as an account with **write/push** rights, or provide a GitHub Personal Access Token with `repo` scope. (The cloud sessions so far only had read access — that's the whole reason edits went through the browser.)

**B. A local build environment.**
- Node 20+ and npm. The session should be able to run `npm install` and `npm run build`.
- First thing to do: `npm install` locally so `package-lock.json` gets refreshed and committed (it currently still lists next 16.1.6 even though the app runs 16.2.10 — see security doc, low-priority item).

**C. Environment variables for local runs — `.env.local`.**
- Copy the **full set** from Vercel → project `my-teamsports` → Settings → Environment Variables. (Don't hand-type; pull them all so nothing's missed.)
- The important ones the app needs: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `NEXT_PUBLIC_TURNSTILE_SITE_KEY` (+ the Turnstile secret), the VAPID keys, `ANTHROPIC_API_KEY`, `RESEND_API_KEY`.
- WARNING: These are live secrets — keep `.env.local` out of git (it already is via `.gitignore`). Never paste secret values into chats or docs.

**D. The plan docs (already in your Claude project "My-Sportsteam.com").**
- `photos-private-bucket-plan.md` — file-by-file plan + safe cutover for the private-bucket change.
- `security-review-2026-07.md` — the master security tracker (what's done, what's left).

**E. Optional infra access (for the bucket flip + deploy checks).**
- Supabase project: `mejkeaoytgblyvqpoyjl` (my-teamsports).
- Vercel project: `my-teamsports` (team `climbo1967's projects`).

---

## 2. The remaining work (priority order)

1. **Enforce the CSP.** It's live in Report-Only. Browse the site with devtools open, clear any `Content-Security-Policy-Report-Only` console violations, then rename the header key to `Content-Security-Policy` in `next.config.mjs` and redeploy.
2. **Harden rate limiting.** `src/lib/ratelimit.js` is in-memory per serverless instance. Move to a shared store (Upstash Redis or a Supabase-backed counter), at least on `team-access`, `ai-coach`, `send-announcement`.
3. **Private photo bucket + signed URLs.** Follow `photos-private-bucket-plan.md`. Good time: the bucket currently has 0 live images. Build on a branch → verify on a Vercel preview → merge → flip `team-media` to private **last**.
4. **Regenerate `package-lock.json`** (falls out of the `npm install` in step B).

---

## 3. Status note (2026-07-10)

The soccer + basketball pSEO batches are merged and deployed; the concurrency caveat from earlier no longer applies, but branch-based work is still recommended. Already done and verified live: paid model + working Stripe checkout, security headers (CSP in Report-Only), Next.js 16.2.10 patch, temp diagnostic endpoint removed.
